# How to View Your Progress on Fitlytic?

To view your progress:
1. Go to the "Progress" section.
2. Choose between "Workout Progress," "Nutrition Progress," or "Goals."
3. View graphs, trends, and personal records.

Visual charts help you understand your improvements and stay motivated.
