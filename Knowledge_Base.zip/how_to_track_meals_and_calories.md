# How to Track Your Meals and Calories on Fitlytic?

To track your meals:
1. Go to the "Nutrition" section in the app.
2. Select "Add Meal."
3. Enter your food items, quantity, and meal type (breakfast, lunch, dinner, snacks).
4. Fitlytic automatically calculates calories and macronutrients.
5. Save the meal entry to track daily intake.

Monitoring nutrition helps you stay aligned with your fitness goals.
