# What Happens If I Miss Logging a Day?

If you miss logging a day:
1)Your progress graph will simply show a gap.
2)You can always manually add past workout or meal entries later.
3)Fitlytic’s smart recommendations will adjust based on updated logs.

Consistency helps, but occasional misses won’t derail your journey!
