# How to Log a Workout on Fitlytic?

To log a workout on Fitlytic:
1. Open the Fitlytic app or web dashboard.
2. Navigate to the "Workouts" section.
3. Click on "Add Workout."
4. Choose your exercise type, set the duration, intensity, and optional notes.
5. Click "Save" to record your workout.

Tracking workouts regularly helps you monitor your fitness journey effectively.
