# How to Connect with a Personal Coach on Fitlytic?

For Premium users:
1. Navigate to "Coaching" in the app.
2. Choose "Request a Personal Coach."
3. Fill in your fitness goals and preferences.
4. A certified coach will be assigned and contact you within 24 hours.

Personal coaches offer tailored workout and nutrition plans.
