# How to Upgrade Your Fitlytic Plan?

To upgrade your plan:
1. Open the app and go to "Settings."
2. Click on "Subscription."
3. Select "Upgrade Plan."
4. Choose your preferred plan (Pro or Premium) and complete the payment.

Upgrading unlocks smart recommendations, personal coaching, and exclusive features!
