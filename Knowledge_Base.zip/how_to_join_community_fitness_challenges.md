# How to Join Community Fitness Challenges on Fitlytic?

To join a challenge:
1. Open the "Community" tab in the app.
2. Browse available challenges.
3. Click "Join" on the challenge you want to participate in.
4. Track your activities to complete challenge milestones.

Challenges keep you motivated and connected with the Fitlytic community!
