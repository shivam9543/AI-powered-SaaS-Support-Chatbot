# How Fitlytic Calculates Your Calorie Burn?

Fitlytic calculates calorie burn based on:
- Your entered workout type and duration
- Your weight, age, and gender details
- Standardized MET (Metabolic Equivalent of Task) values for each activity

This ensures accurate calorie tracking tailored to your body and activities.
