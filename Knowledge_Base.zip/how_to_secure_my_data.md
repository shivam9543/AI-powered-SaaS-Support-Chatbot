# How Secure Is My Data on Fitlytic?

At Fitlytic, we prioritize your privacy and data security:
1)All user data is encrypted during transmission and storage.
2)We adhere to global security standards (like GDPR).
3)Your personal information is never shared without your consent.

Your trust is important to us, and we are committed to keeping your data safe.
