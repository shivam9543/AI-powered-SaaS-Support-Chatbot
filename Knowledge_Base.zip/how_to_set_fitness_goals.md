# How to Set Fitness Goals on Fitlytic?

To set your fitness goals:
1. Navigate to the "Goals" section.
2. Choose your goal type: Weight Loss, Muscle Gain, or Endurance.
3. Enter your target metrics (weight, reps, distance).
4. Set a target date.
5. Save your goal.

Fitlytic will track your progress and provide smart suggestions along the way.
