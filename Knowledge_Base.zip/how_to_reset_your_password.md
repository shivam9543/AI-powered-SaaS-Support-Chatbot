# How to Reset Your Password on Fitlytic?

To reset your password:
1. Click on "Forgot Password" on the login page.
2. Enter your registered email address.
3. You will receive a password reset link.
4. Follow the link to create a new password.

For security, use a strong password that you don't use elsewhere.
